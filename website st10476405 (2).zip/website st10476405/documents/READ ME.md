Project Overview
The Ghetto Fabulous Barber Shop website is a multi-page HTML and CSS project designed to showcase the brand identity, services, and contact information of a vibrant grooming destination located in Johannesburg. The site reflects the shop’s urban style and cultural energy while demonstrating key web development skills including layout design, responsive styling, and user interactivity.

This project was created to meet the requirements of the Wede rubric and includes improvements in structure, design, and accessibility. It features a homepage, service listings, contact form, location map, and price list—all styled consistently using external CSS.
GhettoFabulous/
│
├── index.html               → Homepage
├── About us.html            → About Us page
├── Contact us.html          → Contact page with form
├── Find us.html             → Location and map
├── Price List.html          → Service pricing
│
├── CSS/
│   ├── style.css            → Main stylesheet for all pages
│   ├── About Us.css         → Page-specific styles (optional)
│   ├── Contact Us.css       → Page-specific styles (optional)
│   ├── Find Us.css          → Page-specific styles (optional)
│   ├── Price List.css       → Page-specific styles (optional)
│
└── images/
    ├── G.jpeg               → Logo
    ├── ss.jpeg              → Classic Fade image
    ├── SMS.jpeg             → Cut and Dye image
    ├── K.jpeg               → Premium Cut image
    ├── TMSS.jpeg            → Price list image
    └── SSS.jpg              → Background image

Changelog Table
	Page Updated	Change Description
	index.html	Added Flexbox layout for services section
	style.css	Replaced gradient with background image (SSS.jpg)
	Contact us.html	Added form validation and hover effects
	Find us.html	Embedded Google Map with location pin
    Price List.html	Styled price list image with shadow and border radius
	style.css	Added responsive media queries and fade-in animations
	
	                   Improvement Reflection
This project demonstrates significant improvements in both design and technical execution:

Visual Styling: The use of gradients, shadows, and a branded background image enhances the aesthetic appeal and reflects the shop’s identity.

Layout Structure: Flexbox was implemented to align service boxes in a single row on desktop and stack them on mobile, improving usability.

Interactivity: Hover effects, transitions, and animations were added to buttons, links, and headings to create a dynamic user experience.

Responsiveness: Media queries ensure the site adapts to various screen sizes, maintaining readability and accessibility on mobile devices.

Code Organization: External CSS was used consistently across all pages, separating content from styling and improving maintainability.

                        Screenshot Evidence
To support the improvements made, the following screenshots were captured:

Homepage with Flexbox Services Section Shows three service boxes aligned in one row with hover effects.

Contact Page with Form Styling Displays styled input fields, button hover effect, and responsive layout.

Find Us Page with Embedded Map Shows Google Map integration and location details.

Price List Page with Styled Image Displays price list image with shadow and rounded corners.

Mobile View Screenshot Demonstrates responsive layout with stacked navigation and content.